// This service has been deprecated and disabled as per user request.
// All upscale functionality has been removed from the application.

export const upscaleImageUpscayl = async () => {
    throw new Error("Upscale functionality is disabled.");
};