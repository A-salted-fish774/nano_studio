// This service has been deprecated in favor of the integrated Upscayl engine.
export const upscaleImageClarity = async () => {
  throw new Error("Clarity AI provider is disabled.");
};