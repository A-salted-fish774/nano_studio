// This service has been deprecated in favor of the integrated Upscayl engine.
export const upscaleImageLocal = async () => {
    throw new Error("Legacy local upscaler is disabled.");
};